document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contact-form");
  const resultDiv = document.getElementById("form-result");
  const nameInput = document.getElementById("name");

  nameInput.addEventListener("input", function () {
    document.getElementById("user-name").textContent = nameInput.value || "Name";
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const gender = document.querySelector('input[name="gender"]:checked')?.value;
    const message = document.getElementById("message-input").value;

    if (!nameInput.value || !email || !phone || !gender || !message) {
      alert("Please fill in all fields.");
      return;
    }

    resultDiv.innerHTML = `
      <p><strong>Name:</strong> ${nameInput.value}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Phone:</strong> ${phone}</p>
      <p><strong>Gender:</strong> ${gender}</p>
      <p><strong>Message:</strong> ${message}</p>
    `;
  });
});
